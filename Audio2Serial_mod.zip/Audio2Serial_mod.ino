//#define SERIAL_DEBUG   1

#define PIN_AUDIO_IN_R     A2 //A1
#define ANALOG_THRESHOLD   10 //1023

//#define BAUD_INTERVAL    15625 //240bpm 1s / 64 steps
//#define BAUD_INTERVAL    125000 //240bpm 1s / 16 steps
#define BAUD_INTERVAL   250000 //60bpm 1s / 4 steps

int lvl = 0;
int thr = ANALOG_THRESHOLD;
long bdr = BAUD_INTERVAL;
size_t pos = 0;
uint8_t buf = 0x00;

uint8_t ini = 0x01;
uint8_t msg = 0x08;
uint8_t fin = 0x02;

void setup()
{
    pinMode(LED_BUILTIN, OUTPUT);
    pinMode(PIN_AUDIO_IN_R, INPUT);
    Serial.begin(115200);
    digitalWrite(LED_BUILTIN, HIGH);
}

void loop()
{
    lvl = analogRead(PIN_AUDIO_IN_R);
#ifdef SERIAL_DEBUG
    Serial.println(lvl);
#endif
    //digitalWrite(LED_BUILTIN, (lvl >= thr) ? HIGH : LOW);
#ifndef SERIAL_DEBUG
    if (lvl >= thr)
    {
        digitalWrite(LED_BUILTIN, HIGH);
        buf = 0x00;
        delay(125); //delayMicroseconds(bdr/2); //!!!
        for (int i = 0; i < ini; ++i) { delay(250); } //delayMicroseconds(bdr); }
        for (int i = 0; i < msg; ++i)
        {
            pos = msg - i - 1; //i; //!!!
            lvl = analogRead(PIN_AUDIO_IN_R);
            Serial.print(lvl >= thr);
            if (lvl >= thr) { buf += (1 << pos); }
            delay(250); //delayMicroseconds(bdr);
        }
        for (int i = 0; i < fin; ++i) { delay(250); } //delayMicroseconds(bdr); }
        digitalWrite(LED_BUILTIN, LOW);
        Serial.println();
        Serial.print((int)buf);
        Serial.print(" | ");
        Serial.println((char)buf);
    }
#endif
}
