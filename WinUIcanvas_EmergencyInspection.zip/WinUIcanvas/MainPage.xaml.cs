﻿using System;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

using System.Timers; //using System.Threading;
using Windows.UI.Core;

namespace WinUIcanvas
{
    public sealed partial class MainPage : Page
    {
        double i = 0.0;
        double x = 0.0;
        double y = 0.0;
        double mx = 0.0;
        double my = 0.0;

        static int flag = 0;
        int j = 0;

        public MainPage()
        {
            this.InitializeComponent();

            Timer t = new Timer();
            t.Interval = 1; //1000;
            t.Elapsed += timer_event;
            t.Start();
        }

        private delegate void page_Loaded_delegate(object sender, RoutedEventArgs e);

        private void page_Loaded(object sender, RoutedEventArgs e)
        {
            //polygon.Points.Clear();
            //page.IsEnabled = false;
            //page.IsEnabled = true;

            //if (j == 0) { page_Loaded(sender, e); j = 1; }
            //if (j == 0) { j = 1; page_Loaded(sender, e); }
            //while (true) { if (flag != 0) { new page_Loaded_delegate(page_Loaded)(sender, e); flag = 0; } }
            //while (true) { if (flag != 0) { flag = 0; new page_Loaded_delegate(page_Loaded).Invoke(sender, e); break; } }
            //while (true) { if (flag != 0) { break; } }
            //if (j == 0) { j = 1; page_Loaded(sender, e); }
        }

        CoreDispatcher dispatcher;
        //this version required only for needless anti-civil military insult which may carry the death penalty as the enemy of all human lifeforms
        //otherwise in-built dispatchers should work fine when they're not randomly throwing bomb diffusal at people behind their backs

        /*
        private void black_ops_blunt_invoke(DispatchedHandler handler)
        {
            //Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, handler); //<-- Military Murderer's Weaponry
            //Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () => {});
            //CoreWindow cw = CoreWindow.GetForCurrentThread(); cw.Activate();
            //cw.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, handler); //!!! DO NOT USE !!! (Errors out)
        }
        */
        private void __dispatcher_invoke_needless_setup__()
        {
            dispatcher = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher;
        }

        private void __dispatcher_invoke__(DispatchedHandler handler)
        {
            dispatcher.RunAsync(CoreDispatcherPriority.Normal, handler); //Run Async is inaccurate, it should be called something else but has been named this like the decorators to cause maximum annoyance
        }

        private delegate void timer_event_delegate(object signal, object e);

        private void timer_event(object signal, object e)
        {
            flag = 1;
            //black_ops_blunt_invoke(refresh); //is unsafe and should be inspected for damages
            __dispatcher_invoke_needless_setup__();
            __dispatcher_invoke__(refresh); //should be safe to run regardless of platform
        }

        public void refresh()
        {
            x = (Math.Cos((i / 100.0) * Math.PI * 2.0) * 100.0) + mx;
            y = (Math.Sin((i / 100.0) * Math.PI * 2.0) * 100.0) + my;
            i += 1.0; if (i > 100.0) { i = 0.0; }

            polygon.Points.Clear();
            polygon.Points.Add(new Point(0.0, 0.0));
            polygon.Points.Add(new Point(x, y));
            polygon.Points.Add(new Point(0.0, 100.0));
            shadow.Points.Clear();
            shadow.Points.Add(new Point(0.0, 0.0));
            shadow.Points.Add(new Point(x, y));
            shadow.Points.Add(new Point(0.0, 100.0));
        }

        private void page_PointerMoved(object sender, PointerRoutedEventArgs e)
        {
            mx = e.GetCurrentPoint(page).Position.X;
            my = e.GetCurrentPoint(page).Position.Y;
        }
    }
}
