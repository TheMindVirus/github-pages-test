def goto(fnCb, label, *args, **kwargs):
    fnCb(label, *args, **kwargs)

def fnLibLib(label = 1, *args, **kwargs):
    this = fnLibLib #__func__ #print(__file__) # if (__name__ == "__main__")
    lbl = (this, 2, args, kwargs)
    if label == 1:
        print("do")
        goto(this, 5)
    if label == 2:
        print("in")
        arg = (this, 3) ; goto(*arg) #this.goto(3) 
    if label == 3:
        print("this")
        _ = this ; goto(_, 4)
    if label == 4:
        print("order")
        goto(fnLibLib, 6, *args, **kwargs)
    if label == 5:
        print("it")
        goto(*lbl)

fnLibLib()

class cfnLibLib:
    def __init__(self, index = "1", *args, **kwargs):
        #print(self.__func__)
        if int(index) < 6:
            #self.__goto__(self.__init__, str(int(index) + 1))
            self > (self.__init__, str(int(index) + 1))
    def __gt__(self, call, index = "1", *args, **kwargs):
        print(call, index, *args, **kwargs)
        self.__goto__(*call, index, *args, **kwargs)
    def __goto__(self, call, index = "1", *args, **kwargs):
        print("goto", call, index)
        if call:
            call(index, *args, **kwargs)

cfnll = cfnLibLib()

class cfnliblib:
    def __init__(self, *args, **kwargs):
        self.args = args ; self.kwargs = kwargs
        if "goto" not in kwargs:
            print("init cfnliblib")
            self > "label" #effective goto statement
            return #optional
        else:
            if kwargs["goto"] == "label":
                print("goto", "label")
                print(args, kwargs) #!!!
    def __gt__(self, goto):
        self.__init__(goto = goto, *self.args, **self.kwargs)

fnll = cfnliblib("arg", kwarg = "kwarg")
