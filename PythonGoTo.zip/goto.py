class goto:
    def __init__(self, *args, **kwargs):
        def init(self, *args, **kwargs):
            print("init")
            goto("label") ; return
            print("error")
        def goto(label):
            if label == "label": print("goto", label)
        init(self, *args, **kwargs)
        
init = goto()

class goto:
    def __init__(self, *args, **kwargs):
        self.args = args ; self.kwargs = kwargs
        if "goto" not in kwargs:
            print("init stuff")
            print(args, kwargs)
            unacceptable = False
            condition = not unacceptable
            if condition:
                self > "label" ; return
            print("error out")
        else:
            if kwargs["goto"] == "label":
                print("goto", "label")
                print(args, kwargs)
    def __gt__(self, goto):
        self.__init__(goto = goto, *self.args, **self.kwargs)

init = goto("arg", kwarg = "kwarg")
