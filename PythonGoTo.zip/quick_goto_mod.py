def goto(fnCb, label, *args, **kwargs):
    fnCb(label, *args, **kwargs)

def fnLibLib(label = 1, *args, **kwargs):
    this = fnLibLib #__func__ #print(__file__) # if (__name__ == "__main__")
    lbl = (this, 2, args, kwargs)
    if label == 1:
        print("do")
        goto(this, 5)
    if label == 2:
        print("in")
        arg = (this, 3) ; goto(*arg) #this.goto(3) 
    if label == 3:
        print("this")
        _ = this ; goto(_, 4)
    if label == 4:
        print("order")
        goto(fnLibLib, 6, *args, **kwargs)
    if label == 5:
        print("it")
        goto(*lbl)

fnLibLib()

class cfnLibLib:
    def __init__(self, index = "1", *args, **kwargs):
        #print(self.__func__)
        if int(index) < 6:
            #self.__goto__(self.__init__, str(int(index) + 1))
            self > (self.__init__, str(int(index) + 1))
    def __gt__(self, call, index = "1", *args, **kwargs):
        print(call, index, *args, **kwargs)
        self.__goto__(*call, index, *args, **kwargs)
    def __goto__(self, call, index = "1", *args, **kwargs):
        print("goto", call, index)
        if call:
            call(index, *args, **kwargs)

cfnll = cfnLibLib()

class cfnliblib:
    def __init__(self, *args, **kwargs):
        self.args = args ; self.kwargs = kwargs
        if "goto" not in kwargs:
            print("init cfnliblib")
            self > "label" #effective goto statement
            return #optional
        else:
            if kwargs["goto"] == "label":
                print("goto", "label")
                print(args, kwargs) #!!!
    def __gt__(self, goto):
        self.__init__(goto = goto, *self.args, **self.kwargs)

fnll = cfnliblib("arg", kwarg = "kwarg")

class ccfnliblib:
    def __init__(self):
        def goto(label):
            if label == "label":
                print("goto label")
        goto("label")

ccfnlblb = ccfnliblib()

class ccfnfnliblib:
    def __init__(self):
        print("init stuff")
        #goto("label")
        self.setup()
    def setup(self):
        #goto("label")
        def goto(label):
            if label == "label":
                print("goto label")
        goto("label")

ccfnlblb = ccfnfnliblib()

class cfnlib:
    go2 = None
    def __init__(self):
        if self.label():
            self.goto("label2")
            return
        if self.label("label1"):
            print(self.go2)
            return
        if self.label("label2"):
            print(self.go2)
            self.goto("label1")
            return
    def goto(self, label, cb = __init__):
        self.go2 = label
        cb(self)
    def label(self, label = None):
        return self.go2 == label

cfn = cfnlib()

class ccfnfnliblibmod:
    def __init__(self, *args, **kwargs):
        print("init stuff")
        if "goto" in kwargs:
            goto = kwargs["goto"]
            goto("label")
        #print(self.__init__.goto)
        #goto("label")
        #print(dir())
        def goto(label):
            if label == "label":
                print("goto label")
        if "goto" not in kwargs:
            self.__init__(goto = goto, *args, **kwargs)
        
mod = ccfnfnliblibmod()

class ccfnfnliblibmodmod:
    def __init__(self, *args, **kwargs):
        #return if "goto" not in kwargs else pass
        #if "goto" not in kwargs then return
        if "goto" not in kwargs: goto = self.dummy # ; return
        else: goto = kwargs["goto"]
        goto("label mod")
        def goto(label):
            if label == "label mod":
                print("goto label mod")
        if "goto" not in kwargs:
            self.__init__(goto = goto, *args, **kwargs)
    def dummy(self, *args, **kwargs):
        pass
        
mod = ccfnfnliblibmodmod()

class ccccfnfnliblibmodmod:
    def __init__(self, *args, **kwargs):
        goto = kwargs["goto"] if "goto" in kwargs else self.__null__
        goto("cc")
        if "goto" in kwargs: print("init")
        def goto(lbl):
            if lbl == "cc": print("goto", lbl)
        if "goto" not in kwargs:
            self.__init__(goto = goto, *args, **kwargs)
    def __null__(self, *args, **kwargs):
        pass
        
mod = ccccfnfnliblibmodmod()

class ccccfnfnliblibmodmod:
    def __init__(self, *args, **kwargs):
        goto = kwargs["goto"] if "goto" in kwargs else self.__null__
        def init(self, *args, **kwargs):
            print("init")
            goto("cc")
        if "goto" in kwargs: init(self, *args, **kwargs)
        def goto(lbl):
            if lbl == "cc": print("goto", lbl)
        if "goto" not in kwargs:
            self.__init__(goto = goto, *args, **kwargs)
    def __null__(self, *args, **kwargs):
        pass
        
mod = ccccfnfnliblibmodmod()

class ccccfnfnliblibmodmod:
    def __init__(self, *args, **kwargs):
        def init(self, *args, **kwargs):
            print("init")
            goto("label") ; return
            print("error")
        def goto(label):
            if label == "label": print("goto", label)
        init(self, *args, **kwargs)
        
mod = ccccfnfnliblibmodmod()
