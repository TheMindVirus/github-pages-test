WIDTH = 8
HEIGHT = 8
OFFSET = 0x40 #0x20
GRID = WIDTH * HEIGHT

SPACE = " "
COLON = ":"
COMMA = ","
NEWLINE = "\r\n"
NULL = ".null"

BYTES = 2
ENDIAN = "big"
CODEC = "utf-8"

STARTCHAR = "StartChar"
SPLINESET = "SplineSet"
ENDSPLINESET = "EndSplineSet"
ENDCHAR = "EndChar"

ENCODING = "Encoding"
TEXWIDTH = "Width"
LAYERCOUNT = "LayerCount"
FORE = "Fore"

HEADER = ""
HEADER += TEXWIDTH + COLON + SPACE + str(1000) + NEWLINE
HEADER += LAYERCOUNT + COLON + SPACE + str(2) + NEWLINE

QUAD = []

def QUADPOS(n, p):
    cmd = "l"
    if n == 0:
        cmd = "m"
    if n == 4:
        n = 0
    return SPACE + cmd + SPACE + str(1) + COMMA + str(n + p) + COMMA + str(-1)

def main():
    data = ""
    gen_quad_buffer()
    for i in range(0, GRID):
        #char = (OFFSET + i).to_bytes(BYTES, ENDIAN).decode(CODEC)
        char = NULL
        data += STARTCHAR + COLON + SPACE + char + NEWLINE
        data += ENCODING + COLON + SPACE + str(OFFSET + i) + SPACE + str(-1) + SPACE + str(i) + NEWLINE
        data += HEADER
        sz = len(QUAD)
        count = 0
        for j in range(0, sz):
            if ((i >> j) & 1) != 1:
                continue
            if count == 0:
                data += FORE + NEWLINE + SPLINESET + NEWLINE
            data +=         str(QUAD[j][0][0]) + SPACE + str(QUAD[j][0][1]) + QUADPOS(0, count) + NEWLINE
            data += SPACE + str(QUAD[j][1][0]) + SPACE + str(QUAD[j][1][1]) + QUADPOS(1, count) + NEWLINE
            data += SPACE + str(QUAD[j][2][0]) + SPACE + str(QUAD[j][2][1]) + QUADPOS(2, count) + NEWLINE
            data += SPACE + str(QUAD[j][3][0]) + SPACE + str(QUAD[j][3][1]) + QUADPOS(3, count) + NEWLINE
            data += SPACE + str(QUAD[j][0][0]) + SPACE + str(QUAD[j][0][1]) + QUADPOS(4, count) + NEWLINE
            count += 4
        if count > 0:
            data += ENDSPLINESET + NEWLINE
        data += ENDCHAR + NEWLINE + NEWLINE
        #if i == 1:
        #    print(data)
    #print(data[0:465])
    print(data[953:1525])

    #with open("untitled3_python_generator.txt", "wb") as file:
    #    file.write(data)

def gen_quad_buffer(width = WIDTH, height = HEIGHT,
                    cx = 75, cy = 75, ox = 75, oy = 75, sx = 75, sy = 75):
    global QUAD
    for y in range(0, height):
        for x in range(0, width):
            QUAD.append([])
            QUAD[-1].append([(cx + (ox * x) + (sx * (x + 0))), (cy + (oy * y) + (sy * (y + 0)))])
            QUAD[-1].append([(cx + (ox * x) + (sx * (x + 0))), (cy + (oy * y) + (sy * (y + 1)))])
            QUAD[-1].append([(cx + (ox * x) + (sx * (x + 1))), (cy + (oy * y) + (sy * (y + 1)))])
            QUAD[-1].append([(cx + (ox * x) + (sx * (x + 1))), (cy + (oy * y) + (sy * (y + 0)))])

"""
QUADBUFFER = []
[
    [[115,230], [333,230], [333,75], [115,75]],
    [[,], [,], [,], [,]],
    [[,], [,], [,], [,]],
    [[,], [,], [,], [,]],
    [[115,230], [333,230], [333,75], [115,75]],
    [[,], [,], [,], [,]],
    [[,], [,], [,], [,]],
    [[,], [,], [,], [,]],
]
"""

if __name__ == "__main__":
    main()
