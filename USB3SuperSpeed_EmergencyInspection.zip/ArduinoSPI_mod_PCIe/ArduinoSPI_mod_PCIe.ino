//#pragma push(pack, 1)

#include <SPI.h>

#define SER_SPEED   115200
#define INT_DELAY   1000

#define SPI_SPEED   F_CPU //14000000
#define MIN_BUFSZ   12 //96 //32 * 3

//#define DEBUG   1

//char packet[MIN_BUFSZ] =
//{
//    0xFF, 0xFF, 0xFF, 0xFF,
//    0xFF, 0xFF, 0xFF, 0xFF,
//    0xFF, 0xFF, 0xFF, 0xFF,
//}

char packet[MIN_BUFSZ] = 
{
    0xFF, 0x00, 0x00, 0x00,
    0xFF, 0x00, 0x00, 0x00,
    0xFF, 0x00, 0x00, 0x00,
};

union
{
    struct
    {
        unsigned length : 10;
        unsigned at : 2;
        unsigned attr : 2;
        unsigned ep : 1;
        unsigned td : 1;
        unsigned rsvd1 : 4;
        unsigned tc : 3;
        unsigned rsvd2 : 1;
        unsigned pad : 5;
        unsigned fmt : 2;
        unsigned rsvd3 : 1;
        
        unsigned dwbe1 : 4;
        unsigned dwbe2 : 4;
        unsigned tag : 8;
        unsigned reqid : 16;
        
        unsigned rsvd4 : 2;
        //unsigned addr : 30; //16-bit limit
        unsigned long addr : 30;
    };
    char raw[MIN_BUFSZ];
}   tlp;
/*
union
{
    struct
    {
        unsigned rsvd3 : 1;
        unsigned fmt : 2;
        unsigned pad : 5;
        unsigned rsvd2 : 1;
        unsigned tc : 3;
        unsigned rsvd1 : 4;
        unsigned td : 1;
        unsigned ep : 1;
        unsigned attr : 2;
        unsigned at : 2;        
        unsigned length : 10;

        unsigned reqid : 16;
        unsigned tag : 8;
        unsigned dwbe2 : 4;
        unsigned dwbe1 : 4;

        //unsigned addr : 30; //16-bit limit
        unsigned long addr : 30;
        unsigned rsvd4 : 2;
    };
    char raw[MIN_BUFSZ];
}   tlp;
*/
void setup()
{
    SPI.begin();
    Serial.begin(SER_SPEED);
    pinMode(MOSI, OUTPUT);
    pinMode(MISO, INPUT_PULLUP);
    pinMode(SCK, INPUT_PULLUP);
    pinMode(SS, OUTPUT);
    digitalWrite(SS, LOW);
}

void loop()
{
    SPI.beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE0));
#ifdef DEBUG
    for (size_t i = 0; i < MIN_BUFSZ; ++i) { tlp.raw[i] = packet[i]; }
#else
    for (size_t i = 0; i < MIN_BUFSZ; ++i) { tlp.raw[i] = SPI.transfer(packet[i]); }
#endif
    SPI.endTransaction();
    
    Serial.println("BEGIN_TLP_HEADER");
    Serial.print("length: "); Serial.println(tlp.length);
    Serial.print("at: "); Serial.println(tlp.at);
    Serial.print("attr: "); Serial.println(tlp.attr);
    Serial.print("ep: "); Serial.println(tlp.ep);
    Serial.print("td: "); Serial.println(tlp.td);
    Serial.print("rsvd1: "); Serial.println(tlp.rsvd1);
    Serial.print("tc: "); Serial.println(tlp.tc);
    Serial.print("rsvd2: "); Serial.println(tlp.rsvd2);
    Serial.print("pad: "); Serial.println(tlp.pad);
    Serial.print("fmt: "); Serial.println(tlp.fmt);
    Serial.print("rsvd3: "); Serial.println(tlp.rsvd3);
    Serial.print("dwbe1: "); Serial.println(tlp.dwbe1);
    Serial.print("dwbe2: "); Serial.println(tlp.dwbe2);
    Serial.print("tag: "); Serial.println(tlp.tag);
    Serial.print("reqid: "); Serial.println(tlp.reqid);
    Serial.print("rsvd4: "); Serial.println(tlp.rsvd4);
    //Serial.print("addr: "); Serial.println(tlp.addr);
    Serial.print("addr: 0x"); Serial.println(tlp.addr, HEX); //30-bit address limit
    Serial.println("END_TLP_HEADER");

    for (size_t i = 0; i < MIN_BUFSZ; ++i) { tlp.raw[i] = '\0'; }
    Serial.println();
    delay(INT_DELAY);
}

//#pragma pop(pack)
