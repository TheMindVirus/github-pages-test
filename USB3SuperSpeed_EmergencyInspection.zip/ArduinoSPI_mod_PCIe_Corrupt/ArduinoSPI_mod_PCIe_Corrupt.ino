#include <SPI.h>

#define SPI_SPEED   F_CPU //AVR_CPU_FREQ //14000000
#define MAX_TLPSZ   1 //8192
#define MAX_BUFSZ   5020 //4096 + 24
#define MIN_BUFSZ   12 //96 //32 * 3

char packet[MIN_BUFSZ] =
{
    0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00,
};

char write_buffer[MAX_TLPSZ] = {'\x00'};
char read_buffer[MAX_TLPSZ] = {'\x00'};
char buffer[MAX_BUFSZ] = "";
size_t pos = 0;

size_t t_start = 0;
size_t t_frame = 1000l;
size_t t_count_l = 0;
size_t t_count_h = 0;

size_t max_long = 1000l;

size_t rd_pos = 0;
size_t wr_pos = 0;

union t_tlp_v1
{
    struct
    {
        unsigned length : 10;
        unsigned at : 2;
        unsigned attr : 2;
        unsigned ep : 1;
        unsigned td : 1;
        unsigned rsvd1 : 4;
        unsigned tc : 3;
        unsigned rsvd2 : 1;
        unsigned pad : 5;
        unsigned fmt : 2;
        unsigned rsvd3 : 1;
        unsigned dwbe1 : 4;
        unsigned dwbe2 : 4;
        unsigned tag : 8;
        unsigned reqid : 16;
        unsigned rsvd4 : 2;
        unsigned addr : 30;
    };
    //char raw[];
    char* raw;
    //char raw[MIN_BUFSZ];
};

union t_tlp_v2_12
{
    struct
    {
        char start[1];
        char sequence[2];
        char header[12];
        char payload[MAX_BUFSZ];
        char ecrc[4];
        char lcrc[4];
        char end[1];
    };
    //char raw[];
    char* raw;
    //char raw[MAX_BUFSZ];
};

union t_tlp_v2_16
{
    struct
    {
        char start[1];
        char sequence[2];
        char header[16];
        char payload[MAX_BUFSZ];
        char ecrc[4];
        char lcrc[4];
        char end[1];
    };
    //char raw[];
    char* raw;
    //char raw[MAX_BUFSZ];
};

t_tlp_v1    tlp_v1;
t_tlp_v2_12 tlp_v2_12;
t_tlp_v2_16 tlp_v2_16;

void setup()
{
    SPI.begin();
    Serial.begin(115200);
    pinMode(MOSI, OUTPUT);
    pinMode(MISO, INPUT_PULLUP);
    pinMode(SCK, INPUT_PULLUP);
    pinMode(SS, OUTPUT);
    digitalWrite(SS, LOW);
    //SPI.beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE0));
}

void loop()
{
    //optional burst frames
    //digitalWrite(SS, LOW);
    //SPI.beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE0));
    pos = 0;
    t_count_l = 0;
    t_count_h = 0;
    t_start = millis();
    while ((millis() - t_start) < t_frame)
    {
        write_buffer[wr_pos] = packet[pos];
        read_buffer[rd_pos] = SPI.transfer(write_buffer[wr_pos]);
        buffer[pos] = read_buffer[rd_pos]; ++pos; if (pos >= MAX_BUFSZ) { pos = MAX_BUFSZ - 1; }
        ++t_count_l; if (t_count_l >= max_long) { t_count_l = 0; ++t_count_h; if (t_count_h > max_long) { t_count_h = 0; } }
    }
    //SPI.endTransaction();
    //digitalWrite(SS, HIGH);
    
    //uses absurdly high memory
    //strcpy(buffer, ""); 
    //sprintf(buffer, "0x%00X (%d,%d)", read_buffer[0], t_count_h, t_count_l);
    //Serial.println(buffer);
    
    //tlp_v1.raw = buffer;
    //tlp_v2_12.raw = buffer;
    //tlp_v2_16.raw = buffer;
    //Serial.println();

    //raw[0] = buffer[0];
    //for (size_t i = 0; i < MIN_BUFSZ; ++i) { tlp_v1   .raw[i] = buffer[i]; }
    //for (size_t i = 0; i < MAX_BUFSZ; ++i) { tlp_v2_12.raw[i] = buffer[i]; }
    //for (size_t i = 0; i < MAX_BUFSZ; ++i) { tlp_v2_16.raw[i] = buffer[i]; }
    //Serial.println();
    
    char raw[MIN_BUFSZ] = "";
    for (size_t i = 0; i < MIN_BUFSZ; ++i) { raw[i] = buffer[i]; }
    tlp_v1.raw = raw;

    //char raw_12[MAX_BUFSZ] = "";
    //for (size_t i = 0; i < MAX_BUFSZ; ++i) { raw_12[i] = buffer[i]; }
    //tlp_v2_12.raw = raw_12;

    //char raw_16[MAX_BUFSZ] = "";
    //for (size_t i = 0; i < MAX_BUFSZ; ++i) { raw_16[i] = buffer[i]; }
    //tlp_v2_16.raw = raw_16;
/*
    Serial.println("BEGIN_TLP_HEADER");
    Serial.print("length: "); Serial.println(tlp_v1.length);
    Serial.print("at: "); Serial.println(tlp_v1.at);
    Serial.print("attr: "); Serial.println(tlp_v1.attr);
    Serial.print("ep: "); Serial.println(tlp_v1.ep);
    Serial.print("td: "); Serial.println(tlp_v1.td);
    Serial.print("rsvd1: "); Serial.println(tlp_v1.rsvd1);
    Serial.print("tc: "); Serial.println(tlp_v1.tc);
    Serial.print("rsvd2: "); Serial.println(tlp_v1.rsvd2);
    Serial.print("pad: "); Serial.println(tlp_v1.pad);
    Serial.print("fmt: "); Serial.println(tlp_v1.fmt);
    Serial.print("rsvd3: "); Serial.println(tlp_v1.rsvd3);
    Serial.print("dwbe1: "); Serial.println(tlp_v1.dwbe1);
    Serial.print("dwbe2: "); Serial.println(tlp_v1.dwbe2);
    Serial.print("tag: "); Serial.println(tlp_v1.tag);
    Serial.print("reqid: "); Serial.println(tlp_v1.reqid);
    Serial.print("rsvd4: "); Serial.println(tlp_v1.rsvd4);
    Serial.print("addr: "); Serial.println(tlp_v1.addr);
    Serial.println("END_TLP_HEADER");
*/
    for (size_t i = 0; i < MAX_BUFSZ; ++i) { buffer[i] = '\0'; }
    //Serial.println();
}
