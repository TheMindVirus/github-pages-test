//RS-232 UART over aux MPEG-2 Title channel to VT-100 LCD
//RS-485 _DMX over aux MPEG-3 Audio channel to VT-100 LCD
//RS-422 _PTZ over aux MPEG-4 Video channel to VT-100 LCD

//!!! WARNING !!! Audio To RS-### Is Potentially Damaging To Equipment

#define AUDIO_IN_R_GNDVDD   A0 //A3
#define AUDIO_IN_R_PINOUT   A2 //A1 //Right Channel
#define AUDIO_IN_R_THRESH   A5 //AREF

#define BAUD_RATE       115200 //240bpm on Shift Register
#define BAUD_INTERVAL    62500 //1000000 / BAUD_RATE
#define BAUD_EXTERNAL       A4 //GND

#define BAUD_MAX  1024
#define BAUD_MUL   250
#define BAUD_MIN  9600

#define ENDIANNESS   1

int lvl = 0;
int thr = 0;
long bdr = 0;
size_t pos = 0;
uint8_t buf = 0x00;

uint8_t ini = 0x01;
uint8_t msg = 0x08;
uint8_t fin = 0x02;

//uint8_t tot = ini + msg + fin;
//uint8_t esc = false;
//uint8_t epg = null;

void setup()
{
    //analogReference(EXTERNAL); //analogReference(INTERNAL);
    pinMode(LED_BUILTIN, OUTPUT); digitalWrite(LED_BUILTIN, HIGH);
    pinMode(AUDIO_IN_R_GNDVDD, INPUT); digitalWrite(AUDIO_IN_R_GNDVDD, LOW);
    pinMode(AUDIO_IN_R_PINOUT, INPUT); //, INPUT_PULLUP);
    pinMode(BAUD_EXTERNAL, INPUT); //, INPUT_PULLUP);
    Serial.begin(BAUD_RATE); //Pullup/Pulldown is a Requirement to avoid Garbage when Unplugged
    //TCCR0A = 0b10100011; //Overclocking is only Necessary
    //TCCR0B = 0b00000001; //when using fast paced assembly
    //DIDR0  = 0b00111111; //for pulsing signals manually
}

void loop()
{
    //!!! Experimental !!! Might Not Run Smoothly
    thr = analogRead(AUDIO_IN_R_THRESH);
    //thr = analogRead(AUDIO_IN_R_THRESH); Serial.println(thr);
    //lvl = digitalRead(AUDIO_IN_R_PINOUT);
    lvl = analogRead(AUDIO_IN_R_PINOUT);
    //lvl = (analogRead(AUDIO_IN_R_PINOUT) >= thr) ? AUDIO_IN_R_THRESH : 0;
    //lvl = digitalRead(AUDIO_IN_R_PINOUT); Serial.println(lvl);
    //lvl = analogRead(AUDIO_IN_R_PINOUT); Serial.println(lvl);
    //lvl = (analogRead(AUDIO_IN_R_PINOUT) >= thr) ? AUDIO_IN_R_THRESH : 0; Serial.println(lvl);
    bdr = BAUD_INTERVAL;
    //bdr = (analogRead(BAUD_EXTERNAL) * BAUD_MUL) + BAUD_MIN;
    //bdr = (analogRead(BAUD_EXTERNAL) * BAUD_MUL) + BAUD_MIN; Serial.println(bdr);
    digitalWrite(LED_BUILTIN, (lvl >= thr) ? HIGH : LOW);
    //Serial.println((lvl >= thr) ? 1 : 0);
    if (lvl >= thr)
    {
        buf = 0x00;
        for (int i = 0; i < 11; ++i) { Serial.println((analogRead(AUDIO_IN_R_PINOUT) >= thr) ? "1" : "0"); delayMicroseconds(62500); }
        /*
        for (int i = 0; i < ini; ++i) { delayMicroseconds(bdr); }
        for (int i = 0; i < msg; ++i)
        {
            pos = (ENDIANNESS) ? i : msg - i;
            lvl = analogRead(AUDIO_IN_R_PINOUT);
            if (lvl >= thr) { buf += (1 << pos); }
            delayMicroseconds(bdr);
        }
        for (int i = 0; i < fin; ++i) { delayMicroseconds(bdr); }
        Serial.print((char)buf); //Optionally ASCII Filtered
        */
    }
    
    //Serial.print(analogRead(A1));
    //auto lvl = analogRead(A1);
    //Serial.print(encode(lvl));
    //var lvl = analogRead(A1);
    //Serial.print(decode(lvl));
    
    /*asm volatile
    (
        "ldi r17,0x61\n"
        "ldi r18,0xC3\n"
        "ldi r19,0x00\n"
        "ldi r20,0x00\n"
        "brid lpr1\n"
        "lpr1:\n"
            "sts 0x7C,r17\n"
            "sts 0x7A,r18\n"
        "cdr1:\n"
            "lds r19,0x7A\n"
            "bst r19,6\n"
            "brts cdr1\n"
            //output is custom serial here instead of audio
            //delay implementation is different every time
            "lds r20,0x79\n"
            "sts 0x47,r20\n"
            "brid lpr1\n"
        "brid lpr1\n"
    );*/
}
